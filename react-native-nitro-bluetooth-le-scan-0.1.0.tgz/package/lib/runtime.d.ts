import type { BleScanAdapterState, BleScanConfig, BleScanEvent, BleScanManager, BleScanSnapshot } from './types';
export declare const bleScanManager: BleScanManager;
export declare const getBleAdapterState: () => BleScanAdapterState;
export declare const ensureBleScanPermissions: () => Promise<boolean>;
export declare const startBleScan: (config?: BleScanConfig) => Promise<boolean>;
export declare const stopBleScan: () => Promise<boolean>;
export declare const getBleScanSnapshot: () => BleScanSnapshot;
export declare const subscribeBleScan: (listener: (event: BleScanEvent) => void) => () => void;
