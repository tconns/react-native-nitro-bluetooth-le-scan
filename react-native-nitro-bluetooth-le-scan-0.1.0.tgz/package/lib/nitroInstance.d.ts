import type { NitroBleScan as NitroBleScanSpec } from './specs/NitroBleScan.nitro';
export declare function getNitroBleScan(): NitroBleScanSpec;
